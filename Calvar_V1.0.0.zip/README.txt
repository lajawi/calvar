
Hi, thanks for downloading my pack.

Here are some notes to consider:
- Please read all txt files in the pack, it wil give you information
  about copyright, credits and creator links.
- When you search through the files of this pack, you might stumble
  upon some files that weren't used in the resource pack. This were
  tries for my own, and I wanted to include them for you to explore.
  If you have some basic knowledge of resource pack making, you can
  change the textures and models to be these tries, if you prefer them
  or just want to have a look at them in-game.

Thanks for reading this, and the other files, carefully.